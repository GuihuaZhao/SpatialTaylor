##-------------------------------------------------------------
## SeqFISH Data Analysis
##-------------------------------------------------------------
rm(list = ls())
library(SPARK)

counts <- t(read.csv("./seqFISH_field43_countdata.csv", row.names = 1, check.names = F))  
info <- read.csv("./seqFISH_field43_info.csv", row.names = 1) 
spark <- CreateSPARKObject(counts = counts, location = info[, 1:2], 
                           percentage = 0.1, min_total_counts = 10)  
spark@lib_size <- apply(spark@counts, 2, sum) 
spark <- spark.vc(spark, covariates = NULL, lib_size = spark@lib_size, 
                  num_core = 10, verbose = T, fit.maxiter = 600)  
spark <- spark.test(spark, check_positive = T, verbose = T) 
save(spark, file = "./seqfish_spatialtaylor.rds")

load("./seqfish_spatialtaylor.rds")
head(spark@res_mtest[,c("combined_pvalue","adjusted_pvalue")])
sum(spark@res_mtest$adjusted_pvalue < 0.05,na.rm = T)

##-------------------------------------------------------------
## Spatial Distribution of Representative Genes
##-------------------------------------------------------------
rm(list = ls())
source("E:/funcs/funcs.R")
source("E:/funcs/funcs1.R")
load("E:/output/seqFISH_field43_spark.rds")#SPARK
load("E:/changeSPARK/outputSPARK-master15/seqFISH_field_spark15(4).rds")#SpatialTaylor
counts <- spark@counts
info <- spark@location

newrn <- sapply(strsplit(rownames(counts), split = "'"), "[", 2) 
rownames(counts) <- newrn

gene_plot <- c("Relb","Lhx6","Sox13","Sall3", "Ptch1")

acatp <- spark@res_mtest$combined_pvalue
names(acatp) <- newrn

glsm_res <- t(sapply(1:nrow(spark@counts), function(x) {
  spark@res_vc[[x]]$residuals
}))

rownames(glsm_res) <- rownames(counts) <- sapply(strsplit(rownames(spark@counts), split = "'"), "[[", 2)

sig_glsm_res <- glsm_res[gene_plot, ]
rel_glsm_res <- apply(sig_glsm_res, 1, relative_func)   
pltdat <- cbind.data.frame(info[, 1:2], rel_glsm_res)  

colnames(pltdat) <- c("x", "y", paste0(rownames(sig_glsm_res), " (", format(acatp[gene_plot], 
                                                                            digits = 1), ")"))
pp <- lapply(1:(ncol(pltdat) - 2), function(x) {
  pattern_plot3(pltdat, x, main = T, titlesize = 1.5, pointsize = 3, 
                min.pand = 0.9, max.pand = 1.05)
})
# title = "Relative expression"
library(ggpubr)
ggarrange(pp[[1]],pp[[2]],pp[[3]],pp[[4]],pp[[5]],common.legend=TRUE,legend= "left")


##-------------------------------------------------------------
##  Mouse OB Data Analysis  
##-------------------------------------------------------------
rm(list = ls())
library(SPARK)
# read the raw counts
counts <- read.table("E:/raw_data/Rep11_MOB_count_matrix-1.tsv",check.names = F)

counts <- read.table("./Rep11_MOB_count_matrix-1.tsv",check.names = F)

rn <- rownames(counts)
info <- cbind.data.frame(x = as.numeric(sapply(strsplit(rn, split = "x"), "[", 1)), 
                         y = as.numeric(sapply(strsplit(rn, split = "x"), "[", 2)))
rownames(info) <- rn

spark <- CreateSPARKObject(counts = t(counts), location = info[, 1:2],
                           percentage = 0.1, min_total_counts = 10)
spark@lib_size <- apply(spark@counts, 2, sum)

spark <- spark.vc(spark, covariates = NULL, lib_size = spark@lib_size, 
                  num_core = 10, verbose = T, fit.maxiter = 600)
spark <- spark.test(spark, check_positive = T, verbose = T)

save(spark, file = "./Rep11_MOB_spatialtaylor.rds")#SPARK-master15(4)#260*6932

load("./Rep11_MOB_spatialtaylor.rds")

head(spark@res_mtest[,c("combined_pvalue","adjusted_pvalue")])
sum(spark@res_mtest$adjusted_pvalue < 0.05,na.rm = T)

##-------------------------------------------------------------
## Spatial Distribution of Representative Genes 
##-------------------------------------------------------------
rm(list = ls())
source("E:/funcs/funcs1.R")

counts <- read.table("E:/raw_data/Rep11_MOB_count_matrix-1.tsv",check.names = F)
rn <- rownames(counts)
info <- cbind.data.frame(x = as.numeric(sapply(strsplit(rn, split = "x"), "[", 1)), 
                         y = as.numeric(sapply(strsplit(rn, split = "x"), "[", 2)))
rownames(info) <- rn

gene_plot <- c("Nrip3", "Rtn3", "Nap1l1", "Eif4g3","Arl4a",
               "Zfr")
vst_ct <- var_stabilize(t(counts)) # R function in funcs.R
sig_vst_ct <- vst_ct[gene_plot, ]
rel_vst_ct <- apply(sig_vst_ct, 1, relative_func)
pltdat <- cbind.data.frame(info[,1:2],rel_vst_ct)

genetitle <- c(expression("Nrip3"),
               expression("Rtn3"),
               expression("Nap1l1"),
               expression("Eif4g3"),
               expression("Arl4a"),
               expression("Zfr"))

pp <- lapply(1:(ncol(pltdat)-2),
             function(x){pattern_plot2(pltdat,x,main=T,titlesize=1.5,title=genetitle[x])})
library(ggpubr)
ggarrange(pp[[1]],pp[[2]],pp[[3]],pp[[4]],pp[[5]],pp[[6]],common.legend=TRUE,legend= "left")
grid.arrange(grobs=pp, ncol=3)

##-------GSM4565823——-————-##744*33538 human skin squamous cell carcinomas 人类皮肤鳞状细胞癌
rm(list = ls())

library(SPARK)
counts <- read.csv("./GSM4565823countdata1.csv", row.names = 1, check.names = F)
info <- read.csv("./GSM4565823.csv", row.names = 1, check.names = F) 
spark <- CreateSPARKObject(counts = counts, location = info[, 1:2], 
                           percentage = 0.1, min_total_counts = 10)  

spark@lib_size <- apply(spark@counts, 2, sum) 
write.csv(spark@counts,"E:/Seurat/data/GSM4565823countdata1_spatialtaylor.csv") 
dim(spark@counts)
dim(spark@location)
write.csv(spark@location,"E:/Seurat/data/GSM4565823info_spatialtaylor.csv") 
spark <- spark.vc(spark, covariates = NULL, lib_size = spark@lib_size, 
                  num_core = 10, verbose = T, fit.maxiter = 500)  
spark <- spark.test(spark, check_positive = T, verbose = T) 

save(spark, file = "./GSM4565823_spatialtaylor.rds")

load("./GSM4565823_spatialtaylor.rds")
head(spark@res_mtest[,c("combined_pvalue","adjusted_pvalue")])
sum(spark@res_mtest$adjusted_pvalue < 0.05)


##-------------------------------------------------------------
## Spatial Distribution of Representative Genes
##-------------------------------------------------------------
rm(list = ls())

library(SPARK)

source("E:/funcs/funcs1.R")
counts <- read.csv("E:/Seurat/data/GSM4565823countdata1_spatialtaylor.csv", row.names = 1, check.names = F)
info <- read.csv("E:/Seurat/data/GSM4565823info_spatialtaylor.csv", row.names = 1, check.names = F) 

spark <- CreateSPARKObject(counts = t(counts), location = info[, 1:2], 
                           percentage = 0.1, min_total_counts = 10)
rm(counts, info)

info <- spark@location
info$total_counts <- apply(spark@counts, 2, sum)
counts <- spark@counts

gene_plot <- c("REL","DTYMK","RAD21", "KIF22", "ANP32E",
               "CENPU")

sig_ct <- counts[gene_plot, ]
sig_vst_ct <- var_stabilize(sig_ct)
rel_vst_ct <- apply(sig_vst_ct, 1, relative_func)
pltdat <- cbind.data.frame(info[, 1:2], rel_vst_ct)

# acatp[mainGene]
genetitle <- c(expression("REL "), 
               expression("DTYMK "), 
               expression("RAD21 " ), 
               expression("KIF22 ") , 
               expression("ANP32E " ),
               expression("CENPU " ))


pp <- lapply(1:(ncol(pltdat) - 2), function(x) {
  pattern_plot3(pltdat, x, main = T, titlesize = 1.5, pointsize = 1, 
                title = genetitle[x])
})
library(ggpubr)
ggarrange(pp[[1]],pp[[2]],pp[[3]],pp[[4]],pp[[5]],pp[[6]],common.legend=TRUE,legend= "left")



##------------------------------------------------
## Simulation Data Generation
##------------------------------------------------
## Generate the countdata based on the info from the realdata and
## patterns summarized from the SpatialDE result

## Fold Change
##-----------------
rm(list = ls())

load(paste0("E:/output/SpatialTaylor/Rep11_MOB_spatialtaylor.rds"))

info <- spark@location
info$total_counts <- spark@lib_size

beta <- sapply(1:length(spark@res_vc), function(x) {
  spark@res_vc[[x]]$coefficients
})
nb <- sapply(1:4, function(x) {
  log(x * exp(median(beta)))
})
tau2 <- sapply(1:length(spark@res_vc), function(x) {
  spark@res_vc[[x]]$theta[2]
})

load("E:/output/SpatialTaylor/MOB_Pattern_SpatialDE.rds")
itau = 10
for (ifc in 2:4) {
  newN <- info$total_counts
  for (ipt in 2:4) {
    pattern <- datlist[[paste0("pattern", ipt)]]
    grp <- as.numeric(pattern[, 2] > mean(pattern[, 2])) + 1
    uu <- c(nb[1], nb[ifc], nb[1])
    numSignal <- 1000
    numGene <- 10000
    for (ipow in 1:10) {
      set.seed(ipow)
      beta0 <- uu[grp]
      lambda0 <- sapply(1:numSignal, function(x) {
        exp(beta0 + rnorm(length(beta0), 0, itau/100))
      })
      newCt0 <- lapply(1:numSignal, function(x) {
        rpois(length(lambda0[, x]), newN * lambda0[, x])
      })
      
      beta1 <- rep(uu[3], nrow(pattern))
      lambda1 <- sapply(1:(numGene - numSignal), function(x) {
        exp(beta1 + rnorm(length(beta1), 0, itau/100))
      })
      newCt1 <- lapply(1:(numGene - numSignal), function(x) {
        rpois(length(lambda1[, x]), newN * lambda1[, x])
      })
      
      countdata <- data.frame(rbind(do.call(rbind, newCt0), do.call(rbind, 
                                                                    newCt1)))
      rownames(countdata) <- paste0("gene", 1:nrow(countdata))
      colnames(countdata) <- pattern[, 1]
      
      write.csv(t(countdata), file = paste0("./sim2_MOB_pattern", 
                                            ipt, "_fc", ifc, "_tau", itau, "_count_power", ipow, ".csv"), 
                row.names = T)
    }
  }
}

write.csv(info, file = "./Rep11_MOB_info_spark.csv", row.names = T)

## Noise Change
##-----------------

rm(list = ls())
load(paste0("E:/output/SpatialTaylor/Rep11_MOB_spatialtaylor.rds"))
info <- spark@location
info$total_counts <- spark@lib_size

beta <- sapply(1:length(spark@res_vc), function(x) {
  spark@res_vc[[x]]$coefficients
})
nb <- sapply(1:4, function(x) {
  log(x * exp(median(beta)))
})
tau2 <- sapply(1:length(spark@res_vc), function(x) {
  spark@res_vc[[x]]$theta[2]
})
load("./MOB_Pattern_SpatialDE.rds")
load("E:/output/MOB_Pattern_SpatialDE.rds")

#(itau in c(20, 30))
for (itau in c(40, 50)) {
  for (ifc in 2:4) {
    newN <- info$total_counts
    for (ipt in 2:4) {
      pattern <- datlist[[paste0("pattern", ipt)]]
      grp <- as.numeric(pattern[, 2] > mean(pattern[, 2])) + 1
      uu <- c(nb[1], nb[ifc], nb[1])
      numSignal <- 1000
      numGene <- 10000
      
      for (ipow in 1:10) {
        set.seed(ipow)
        beta0 <- uu[grp]
        lambda0 <- sapply(1:numSignal, function(x) {
          exp(beta0 + rnorm(length(beta0), 0, itau/100))
        })
        newCt0 <- lapply(1:numSignal, function(x) {
          rpois(length(lambda0[, x]), newN * lambda0[, x])
        })         
        beta1 <- rep(uu[3], nrow(pattern))
        lambda1 <- sapply(1:(numGene - numSignal), function(x) {
          exp(beta1 + rnorm(length(beta1), 0, itau/100))
        })
        newCt1 <- lapply(1:(numGene - numSignal), function(x) {
          rpois(length(lambda1[, x]), newN * lambda1[, x])
        })
        
        countdata <- data.frame(rbind(do.call(rbind, newCt0), do.call(rbind, newCt1)))
        rownames(countdata) <- paste0("gene", 1:nrow(countdata))
        colnames(countdata) <- pattern[, 1]
        
        write.csv(t(countdata), file = paste0("./sim2_MOB_pattern", 
                                              ipt, "_fc", ifc, "_tau", itau, "_count_power", ipow, 
                                              ".csv"), row.names = T)
      }
    }
  }
}

