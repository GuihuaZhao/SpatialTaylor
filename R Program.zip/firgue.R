getwd()
setwd("C:/Users/Samsung/Desktop/SpatialTaylor/")

#tau-AUC对比图
log_data <- read.csv("./SpatialTaylor/data/AUC_all_Tau1.csv")
head(log_data)
log_data$tau <- as.factor(log_data$tau)#将tau变量转变为因子变量
p1 = ggplot(log_data, aes(x=tau, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab(expression(tau[2]))+theme(axis.title.x = element_text(size=18))#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p1
#tau-FPR对比图
log_data <- read.csv("./SpatialTaylor/data/FPR-all-tau.csv")
head(log_data)
log_data$tau <- as.factor(log_data$tau)#将tau变量转变为因子变量
p2 = ggplot(log_data, aes(x=tau, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab(expression(tau[2]))+theme(axis.title.x = element_text(size=18))#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p2
#tau-TPR对比图
log_data <- read.csv("./SpatialTaylor/data/TPR-all-tau.csv")
head(log_data)
log_data$tau <- as.factor(log_data$tau)#将tau变量转变为因子变量
p3 = ggplot(log_data, aes(x=tau, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab(expression(tau[2]))+theme(axis.title.x = element_text(size=18))#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p3
library(ggpubr)
pp1<-ggarrange( p1, p2,p3,ncol=3,common.legend=TRUE,legend= "right")#,labels = c("a","b","c")
pp1

#cells-AUC对比图
log_data <- read.csv("./SpatialTaylor/data/AUC-all-cell.csv")
head(log_data)
#colnames(log_data)[3]="cell number"修改某一列的列名
log_data$cells <- as.factor(log_data$cells)#cells变量转变为因子变量
p1 = ggplot(log_data, aes(x=cells, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab("Cell numbers")#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p1
#cells-FPR对比图
log_data <- read.csv("./SpatialTaylor/data/FPR-all-cell.csv")
#colnames(log_data)[3]="cell number"
head(log_data)
log_data$cells <- as.factor(log_data$cells)#cells变量转变为因子变量
p2 = ggplot(log_data, aes(x=cells, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab("Cell numbers")#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p2
#cells-TPR对比图
log_data <- read.csv("./SpatialTaylor/data/TPR-all-cell.csv")
#colnames(log_data)[3]="cell number"
head(log_data)
log_data$cells <- as.factor(log_data$cells)#cells变量转变为因子变量
p3 = ggplot(log_data, aes(x=cells, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()+xlab("Cell numbers")#fill=Methods 填充颜色 theme_classic()保留x和y轴
#p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p3
library(ggpubr)
pp2<-ggarrange( p1, p2,p3,ncol=3,common.legend=TRUE,legend= "right")#,labels = c("a","b","c")
pp2



# 箱线图
#totaldata
rm(list = ls())
library(ggplot2)
log_data <- read.csv("./SpatialTaylor/data/AUC-totaldata1.csv")#AUC-totaldata.csv
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1 = ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p1<-p1+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))##离散变量填充色
p1

#p1<-ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
#  geom_boxplot(position=position_dodge(1))

library(ggplot2)
log_data <- read.csv("./SpatialTaylor/data/FPR-totaldata1.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2 = ggplot(log_data, aes(x=Methods, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p2<-p2+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2

library(ggplot2)
log_data <- read.csv("./SpatialTaylor/data/TPR-totaldata1.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p3 = ggplot(log_data, aes(x=Methods, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p3<-p3+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p3

library(ggpubr)
pp3<-ggarrange(p1, p2, p3,ncol=3,common.legend=TRUE,legend= "right")
pp3

pp<-ggarrange( pp3, pp1,pp2,ncol=1,common.legend=TRUE,legend= "right")#,,labels = c("a","b","c","d")
pp


# 分开的箱线图
#totaldata
rm(list = ls())
library(ggplot2)
log_data <- read.csv("./data/AUC-totaldata.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p = ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p

library(ggplot2)
log_data <- read.csv("./data/TPR-totaldata.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1 = ggplot(log_data, aes(x=Methods, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p1<-p1+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1

library(ggplot2)
log_data <- read.csv("./data/FPR-totaldata.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2 = ggplot(log_data, aes(x=Methods, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p2<-p2+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2

library(ggpubr)
pp<-ggarrange(p, p1, p2,ncol=3,common.legend=TRUE,legend= "right")
pp


# 箱线图
#tau
rm(list = ls())
library(ggplot2)
log_data <- read.csv("./data/AUC-tau.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p = ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p

library(ggplot2)
log_data <- read.csv("./data/TPR-tau.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1 = ggplot(log_data, aes(x=Methods, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p1<-p1+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1

library(ggplot2)
log_data <- read.csv("./data/FPR-tau.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2 = ggplot(log_data, aes(x=Methods, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p2<-p2+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2

library(ggpubr)
pp<-ggarrange(p, p1, p2,ncol=3,common.legend=TRUE,legend= "right")
pp


# 箱线图
#cell
rm(list = ls())
library(ggplot2)
log_data <- read.csv("./data/AUC-cell.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p = ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p

library(ggplot2)
log_data <- read.csv("./data/TPR-cell.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1 = ggplot(log_data, aes(x=Methods, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p1<-p1+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1

library(ggplot2)
log_data <- read.csv("./data/FPR-cell.csv")
head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2 = ggplot(log_data, aes(x=Methods, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p2<-p2+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2

library(ggpubr)
pp<-ggarrange(p, p1, p2,ncol=3,common.legend=TRUE,legend= "right")
pp


# 箱线图AUC
rm(list = ls())
library(ggplot2)

log_data <- read.csv("./data/AUC-tau-10.csv")
log_data <- read.csv("./data/AUC-tau-20.csv")
log_data <- read.csv("./data/AUC-tau-30.csv")
log_data <- read.csv("./data/AUC-tau-40.csv")
log_data <- read.csv("./data/AUC-tau-50.csv")

log_data <- read.csv("./data/AUC-cell2.csv")
log_data <- read.csv("./data/AUC-cell3.csv")
log_data <- read.csv("./data/AUC-cell4.csv")

head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p = ggplot(log_data, aes(x=Methods, y=AUC,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p<-p+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p


# 箱线图TPR
library(ggplot2)

log_data <- read.csv("./data/TPR-tau-10.csv")
log_data <- read.csv("./data/TPR-tau-20.csv")
log_data <- read.csv("./data/TPR-tau-30.csv")
log_data <- read.csv("./data/TPR-tau-40.csv")
log_data <- read.csv("./data/TPR-tau-50.csv")

log_data <- read.csv("./data/TPR-cell2.csv")
log_data <- read.csv("./data/TPR-cell3.csv")
log_data <- read.csv("./data/TPR-cell4.csv")

head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1 = ggplot(log_data, aes(x=Methods, y=TPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p1<-p1+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p1

# 箱线图FPR
library(ggplot2)

log_data <- read.csv("./data/FPR-tau-10.csv")
log_data <- read.csv("./data/FPR-tau-20.csv")
log_data <- read.csv("./data/FPR-tau-30.csv")
log_data <- read.csv("./data/FPR-tau-40.csv")
log_data <- read.csv("./data/FPR-tau-50.csv")

log_data <- read.csv("./data/FPR-cell2.csv")
log_data <- read.csv("./data/FPR-cell3.csv")
log_data <- read.csv("./data/FPR-cell4.csv")

head(log_data)
log_data$Methods <- factor(log_data$Methods,levels = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2 = ggplot(log_data, aes(x=Methods, y=FPR,fill=Methods)) +
  geom_boxplot()+theme_classic()#fill=Methods 填充颜色 theme_classic()保留x和y轴
p2<-p2+scale_fill_discrete(limits = c("SpatialTaylor", "SpatialDE", "SPARK"))
p2


library(ggpubr)
pp<-ggarrange(p, p1, p2,ncol=3,common.legend=TRUE,legend= "right")
pp


#Venn diagram
#seqfish数据韦恩图
rm(list = ls())
library(VennDiagram)
venn.plot <- draw.triple.venn(
  area1 = 17,
  area2 = 19,
  area3 = 11,
  n12 = 14,
  n23 = 11,
  n13 = 11,
  n123 = 11,
  category = c("SPARK","SpatialTayplor","SpatialDE"),
  fill = c("purple", "pink", "green"),
  lty = "blank",
  cex = 2,
  cat.cex = 2,
  cat.col = c("purple", "pink", "green")
)
grid.draw(venn.plot)#画图展示

#Mouse ob数据韦恩图
rm(list = ls())
library(VennDiagram)
venn.plot <- draw.triple.venn(
  area1 = 751,
  area2 = 1132,
  area3 = 67,
  n12 = 483,
  n23 = 58,
  n13 = 60,
  n123 = 58,
  category = c("SPARK","SpatialTaylor","SpatialDE"),
  fill = c("purple", "pink", "green"),
  lty = "blank",
  cex = 2,
  cat.cex = 2,
  cat.col = c("purple", "pink", "green")
)
grid.draw(venn.plot)#画图展示

venn.plot <- draw.triple.venn(
  area1 = 751,
  area2 = 1132,
  area3 = 67,
  n12 = 483,
  n23 = 58,
  n13 = 60,
  n123 = 58,
  category = c("SPARK","SpatialTaylor","SpatialDE"),
  fill = c("purple", "pink", "green"),
  lty = "blank",
  cex = 2,
  cat.cex = 2,
  cat.col = c("purple", "pink", "green")
)
grid.draw(venn.plot)#画图展示

###--GSM4565823——human skin squamous cell carcinomas 
##人类皮肤鳞状细胞癌韦恩图
rm(list = ls())
library(VennDiagram)
venn.plot <- draw.triple.venn(
  area1 = 4254,
  area2 = 5372,
  area3 = 4424,
  n12 = 3151,
  n23 = 3963,
  n13 = 3340,
  n123 = 2989,
  category = c("SPARK","SpatialTaylor","SpatialDE"),
  fill = c("purple", "pink", "green"),
  lty = "blank",
  cex = 2,
  cat.cex = 2,
  cat.col = c("purple", "pink", "green")
)
grid.draw(venn.plot)#画图展示

##cscc人类皮肤鳞状细胞癌数据条形图
rm(list = ls())
#ggplot2绘制柱状图
library(ggplot2)
counts <- read.csv("./cscc.csv",check.names=F)
#stat=”“identity”:指定了柱状图的高度（y）
#fill=obj：填充的柱状图的颜色
data1=na.omit(counts[c("Methods","genes")])
ggplot(data=data1,mapping=aes(x=Methods,y=genes,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity")
#修改柱状图的宽度width=0.5
ggplot(data=data1,mapping=aes(x=Methods,y=genes,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity",width=0.5)
#修改柱形图的顺序
data1<-within(data1,{
  Methods<-factor(Methods,levels=c("SpatialTaylor","SPARK","SpatialDE"))
})
P_5<-ggplot(data=data1,mapping=aes(x=Methods,y=genes,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity",width=0.5)+
  geom_text(aes(label = genes, vjust = -0.8, hjust = 0.5, color = Methods), show.legend = TRUE)+
  theme_classic()+  ylim(0, 40)+theme(axis.title.x = element_text(size=14),axis.title.y = element_text(size=14))#去除背景颜色
P_5

##Mobdata数据条形图
rm(list = ls())
#ggplot2绘制柱状图
library(ggplot2)
counts <- read.csv("./data/MOB-Harmonizome1.genes.csv",check.names=F)
#stat=”“identity”:指定了柱状图的高度（y）
#fill=obj：填充的柱状图的颜色
data1=na.omit(counts[c("Methods","recall")])
ggplot(data=data1,mapping=aes(x=Methods,y=recall,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity")
#修改柱状图的宽度width=0.5
ggplot(data=data1,mapping=aes(x=Methods,y=recall,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity",width=0.5)
#修改柱形图的顺序
data1<-within(data1,{
  Methods<-factor(Methods,levels=c("SpatialTaylor","SPARK","SpatialDE"))
})
ggplot(data=data1,mapping=aes(x=Methods,y=recall,fill=Methods,group=factor(1)))+
  geom_bar(stat="identity",width=0.5)+
  geom_text(aes(label = recall, vjust = -0.8, hjust = 0.5, color = Methods), show.legend = TRUE)+
  theme_classic()+  ylim(0, 400)#去除背景颜色



#qq图Seqfish
rm(list=ls())
library(openxlsx)
library("qqman")
pvalue<-read.csv(".output/seqpermSPARKpvalue.csv")
#qq(pvalue$x, col = "blue4", cex = 1.5, las = 1,xlim = c(0, 1.5), ylim = c(0, 15))
qq(pvalue$x, col = "blue4", cex = 1.5, las = 1,xlim = c(0, 5), ylim = c(0, 6), bty="l")
#pvalue<-read.csv("E:/changeSPARK/perm-SPARK-master3/outseq/seqpermpval.csv")
pvalue<-read.csv("./output/seqSpatialTaylorpval.csv")
par(new = TRUE)
#qq(pvalue$pval,  col = "red", cex = 1.5, las = 1,xlim = c(0, 1.5), ylim = c(0, 15))
qq(pvalue$pval,  col = "red", cex = 1.5, las = 1,xlim = c(0, 5), ylim = c(0, 6), bty="l")
par(new = TRUE)
pvalue<-read.xlsx("./output/seqpermSpatialDEpval.xlsx")
qq(pvalue$pval, col = "green3", cex = 1.5, las = 1,xlim = c(0, 5), ylim = c(0, 6), bty="l")
legend("topleft",cex=0.6,pch=c(15,15),legend=c("SpatialTaylor","SPARK","SpatialDE"),col=c(2,1,3),bty="n")


###进行GO和KEGG分析；
rm(list = ls())
library(clusterProfiler)
library(org.Mm.eg.db)
library(org.Hs.eg.db)
a <- read.table(file.choose(),header = F,colClasses = c("V1"= "character"))
b <- a[,1]
eg <- bitr(b,fromType = "SYMBOL",
           toType = "ENTREZID",
           OrgDb = "org.Mm.eg.db")
gene <- eg[,2]
ego_all <- enrichGO(gene = gene,
                    OrgDb=org.Mm.eg.db,
                    ont = "all",
                    pAdjustMethod = "BH",
                    #minGSSize = 1,
                    pvalueCutoff = 0.01,
                    qvalueCutoff = 0.05,
                    readable = TRUE)
write.csv(as.data.frame(ego_all),
          row.names = F, file = "./data/ego_MOBSpatialTaylor.csv")
dotplot(ego_all,showCategory=20,title = "MobSpatialTaylorenrichment")#气泡图

####Seurat细胞聚类
##-------------------------------------------------------------
## GSE60361 Data Analysis  the mouse hippocampus 小鼠海马体
##-------------------------------------------------------------

rm(list = ls())
library(dplyr)
library(Seurat)
library(patchwork)

# Load the GSE60361 dataset
GSE60361 <- read.csv("./data/GSE60361.csv", row.names = 1, 
                     check.names = F) 
# Initialize the Seurat object with the raw (non-normalized data).
GSE60361 <- CreateSeuratObject(counts = GSE60361, project = "GSE60361", min.cells = 3, min.features = 200)
GSE60361#查看数据

# The [[ operator can add columns to object metadata. This is a great place to stash QC stats
GSE60361[["percent.mt"]] <- PercentageFeatureSet(GSE60361, pattern = "^MT-")
# Visualize QC metrics as a violin plot
VlnPlot(GSE60361, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
# FeatureScatter is typically used to visualize feature-feature relationships, but can be used
# for anything calculated by the object, i.e. columns in object metadata, PC scores etc.

plot1 <- FeatureScatter(GSE60361, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(GSE60361, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1 + plot2
GSE60361 <- subset(GSE60361, subset = nFeature_RNA > 200 & nFeature_RNA < 80000 & percent.mt < 5)
GSE60361 <- NormalizeData(GSE60361, normalization.method = "LogNormalize", scale.factor = 10000)
GSE60361 <- FindVariableFeatures(GSE60361, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(GSE60361), 10)
top10
# plot variable features with and without labels
plot1 <- VariableFeaturePlot(GSE60361)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 
plot2

all.genes <- rownames(GSE60361)
#View(all.genes)
GSE60361 <- ScaleData(GSE60361, features = all.genes)

GSE60361 <- RunPCA(GSE60361, features = VariableFeatures(object = GSE60361))

# Examine and visualize PCA results a few different ways
print(GSE60361[["pca"]], dims = 1:5, nfeatures = 5)

VizDimLoadings(GSE60361, dims = 1:2, reduction = "pca")
DimPlot(GSE60361, reduction = "pca")

DimHeatmap(GSE60361, dims = 1, cells = 500, balanced = TRUE)

DimHeatmap(GSE60361, dims = 1:15, cells = 500, balanced = TRUE)

# NOTE: This process can take a long time for big datasets, comment out for expediency. More
# approximate techniques such as those implemented in ElbowPlot() can be used to reduce
# computation time
GSE60361 <- JackStraw(GSE60361, num.replicate = 100)
GSE60361 <- ScoreJackStraw(GSE60361, dims = 1:20)

JackStrawPlot(GSE60361, dims = 1:15)

ElbowPlot(GSE60361)
GSE60361 <- FindNeighbors(GSE60361, dims = 1:20)
GSE60361 <- FindClusters(GSE60361, resolution = 0.5)

# Look at cluster IDs of the first 5 cells
head(Idents(GSE60361), 5)

# If you haven't installed UMAP, you can do so via reticulate::py_install(packages =
# 'umap-learn')
# note that you can set `label = TRUE` or use the LabelClusters function to help label
# individual clusters

GSE60361 <- RunUMAP(GSE60361, dims = 1:20)##进行UMAP进行降维
P1 <- DimPlot(GSE60361, reduction = "umap", label = TRUE)

GSE60361 <- RunTSNE(GSE60361, dims = 1:20)##进行TSNE进行降维
P2 <- DimPlot(GSE60361, reduction = "tsne",label = TRUE)
P1 + P2
P1
P2
saveRDS(GSE60361, file = "E:/Seurat/output/GSE60361_tutorial.rds")
load("E:/Seurat/output/GSE60361_tutorial.rds")
# find all markers of cluster 2
cluster2.markers <- FindMarkers(GSE60361, ident.1 = 2, min.pct = 0.25)
head(cluster2.markers, n = 5)

cluster11.markers <- FindMarkers(GSE60361, ident.1 = 11, min.pct = 0.25)
head(cluster2.markers, n = 5)

cluster15.markers <- FindMarkers(GSE60361, ident.1 = 15, min.pct = 0.25)
head(cluster2.markers, n = 5)

# find all markers distinguishing cluster 5 from clusters 0 and 3
cluster5.markers <- FindMarkers(GSE60361, ident.1 = 5, ident.2 = c(0, 3), min.pct = 0.25)
head(cluster5.markers, n = 5)

# find markers for every cluster compared to all remaining cells, report only the positive
# ones
GSE60361.markers <- FindAllMarkers(GSE60361, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
GSE60361.markers %>%
  group_by(cluster) %>%
  slice_max(n = 2, order_by = avg_log2FC)
print(GSE60361.markers %>%
        group_by(cluster) %>%
        slice_max(n = 5, order_by = avg_log2FC), n = 95)

print(GSE60361.markers %>%
        group_by(cluster) %>%
        slice_max(n = 5, order_by = avg_log2FC), n = 95)


GSE60361.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC) -> top10
## DoHeatmap()为给定的单元格和特征生成表达式热图
DoHeatmap(GSE60361, features = top10$gene) + NoLegend()

new.cluster.ids <- c("Type II spiral ganglion neuron", 
                     "Oligodendrocyte", 
                     "Type IC spiral ganglion neuron",
                     "CCK basket cell", 
                     "Endothelial cell", 
                     "Bergmann glial cell",
                     "Type I spiral ganglion neuron", 
                     "Neuron", 
                     "O cell",
                     "Interneuron-selective cell", 
                     "Fibroblast", 
                     "Long-projecting GABAergic cell",
                     "Type IA spiral ganglion neuron", 
                     "Mural cell", 
                     "Macrophage",
                     "Neural stem cell",
                     "Medullary cell", 
                     "Microglial cell", 
                     "M1 macrophage")


names(new.cluster.ids) <- levels(GSE60361)
GSE60361 <- RenameIdents(GSE60361, new.cluster.ids)
DimPlot(GSE60361, reduction = "umap", label = TRUE, pt.size = 0.5) + NoLegend()
DimPlot(GSE60361, reduction = "umap", label = TRUE, pt.size = 0.5) 

cluster0.markers <- FindMarkers(GSE60361, ident.1 = 0, logfc.threshold = 0.25, test.use = "roc", only.pos = TRUE)

VlnPlot(GSE60361, features = c("Lhx6", "Sall3"),pt.size = 0)#小提琴图



# you can plot raw counts as well
VlnPlot(GSE60361, features = c("Lhx6", "Sall3"), slot = "counts", log = TRUE)

FeaturePlot(GSE60361, features = c("Lhx6", "Sall3"))


GSE60361.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC) -> top10
DoHeatmap(GSE60361, features = top10$gene) + NoLegend()


#-----------------------------------------------------------------
##-------GSM4565823——-————-
##744*33538 human skin squamous cell carcinomas 人类皮肤鳞状细胞癌
##----------------------------------------------------------------
rm(list = ls())
library(dplyr)
library(Seurat)
library(patchwork)
plan("multisession", workers = 4)

counts <- read.csv("./GSM4565823countdata1.csv", row.names = 1, check.names = F)
GSM4565823 <- CreateSeuratObject(counts = counts, project = "GSM4565823", min.cells = 3, min.features = 200)

###通过CreateSeuratObject()创建一个Seurat对象，
#其包含矩阵数据和各类分析(如Data count 和PCA以及Cluster分析的结果
GSM4565823

GSM4565823[["percent.mt"]] <- PercentageFeatureSet(GSM4565823, pattern = "^MT-")

# Visualize QC metrics as a violin plot  ###通过小提琴图进行可视化，发现nFeature_RNA 的
VlnPlot(GSM4565823, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

# FeatureScatter is typically used to visualize feature-feature relationships, but can be used
# for anything calculated by the object, i.e. columns in object metadata, PC scores etc.

plot1 <- FeatureScatter(GSM4565823, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(GSM4565823, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot1 + plot2

GSM4565823 <- subset(GSM4565823, subset = nFeature_RNA > 0 & nFeature_RNA < 7000 & percent.mt < 5)
#数据的归一化 采取的方法
GSM4565823 <- NormalizeData(GSM4565823, normalization.method = "LogNormalize", scale.factor = 10000)

GSM4565823 <- FindVariableFeatures(GSM4565823, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(GSM4565823), 10)
top10
top20 <- head(VariableFeatures(GSM4565823), 20)
top20
# plot variable features with and without labels
plot1 <- VariableFeaturePlot(GSM4565823)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 
plot2

###Scaling the data
all.genes <- rownames(GSM4565823)
GSM4565823 <- ScaleData(GSM4565823, features = all.genes)
#View(all.genes)
#View(GSM4565823[["RNA"]]@scale.data)

GSM4565823 <- RunPCA(GSM4565823, npcs = 30,features = VariableFeatures(object = GSM4565823))##进行PCA操作
##对PCA进行可视化操作的方法
print(GSM4565823[["pca"]], dims = 1:5, nfeatures = 5)
VizDimLoadings(GSM4565823, dims = 1:2, reduction = "pca")##分别查看对PC1和PC2其主要作用的基因
DimPlot(GSM4565823, reduction = "pca")###通过点图展示PC1和PC2

DimHeatmap(GSM4565823, dims = 1, cells = 500, balanced = TRUE)##通过热图可以对PC成分进行可视化，允许我们对基因集的异质性进行审阅，从而决定哪个PC可用于后续的下游分析，一般默认可以选择500个细胞，细胞和基因都是按照PCA的分值进行排序的。
dims=1:15  #画出1:15 的PC热图
DimHeatmap(GSM4565823, dims = 1:15, cells = 500, balanced = TRUE) #15个PC


GSM4565823 <- JackStraw(GSM4565823, num.replicate = 100)
GSM4565823 <- ScoreJackStraw(GSM4565823, dims = 1:20)

JackStrawPlot(GSM4565823, dims = 1:20)###对结果进行可视化


ElbowPlot(GSM4565823)

GSM4565823 <- FindNeighbors(GSM4565823, dims = 1:15)
#resolution参数：值越大，细胞分群数越多,3000细胞的时候，选择0.4-1.2。 大的数据集的时候，resolution相应加大
GSM4565823 <- FindClusters(GSM4565823, resolution = 0.3)
GSM4565823 <- FindClusters(GSM4565823, resolution = 0.5)
# Look at cluster IDs of the first 5 cells
head(Idents(GSM4565823), 5)

###使用t-SNE 和UMAP进行可视化降维的结果
GSM4565823 <- RunUMAP(GSM4565823, dims = 1:20)##进行UMAP进行降维

# note that you can set `label = TRUE` or use the LabelClusters function to help label
# individual clusters
DimPlot(GSM4565823, reduction = "umap",label = TRUE)

GSM4565823 <- RunTSNE(GSM4565823, dims = 1:20)##进行TSNE进行降维
DimPlot(GSM4565823, reduction = "tsne",label = TRUE)


saveRDS(GSM4565823, file = "E:/Seurat/output/GSM4565823_tutorial.rds")
load("E:/Seurat/output/GSM4565823_tutorial.rds")
# find all markers of cluster 2
cluster1.markers <- FindMarkers(GSM4565823, ident.1 = 1, min.pct = 0.25)
head(cluster1.markers, n = 5)

# find all markers distinguishing cluster 5 from clusters 0 and 3
cluster2.markers <- FindMarkers(GSM4565823, ident.1 = 2, ident.2 = c(0, 1), min.pct = 0.25)
head(cluster2.markers, n = 5)

# find markers for every cluster compared to all remaining cells, report only the positive
# ones
GSM4565823.markers <- FindAllMarkers(GSM4565823, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
GSM4565823.markers %>%
  group_by(cluster) %>%
  slice_max(n = 2, order_by = avg_log2FC)
print(GSM4565823.markers %>%
        group_by(cluster) %>%
        slice_max(n = 10, order_by = avg_log2FC),n=50)

cluster0.markers <- FindMarkers(GSM4565823, ident.1 = 0, logfc.threshold = 0.25, test.use = "roc", only.pos = TRUE)
cluster3.markers <- FindMarkers(GSM4565823, ident.1 = 0, logfc.threshold = 0.25, test.use = "roc", only.pos = TRUE)

VlnPlot(GSM4565823, features = c("REL","DTYMK","RAD21", "KIF22", "ANP32E",
                                 "CENPU"),pt.size = 0)

FeaturePlot(GSM4565823, features = c("REL","DTYMK","RAD21", "KIF22", "ANP32E",
                                     "CENPU"))
GSM4565823.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC) -> top10

DoHeatmap(GSM4565823, features = top10$gene) + NoLegend()

## DoHeatmap()为给定的单元格和特征生成表达式热图
DoHeatmap(GSM4565823, features = top10$gene) + NoLegend()
new.cluster.ids <- c("Stromal cell", 
                     "Basal cell", 
                     "B cell",
                     "Endothelial cell", 
                     "Regulatory T (Treg) cell")
names(new.cluster.ids) <- levels(GSM4565823)
GSM4565823 <- RenameIdents(GSM4565823, new.cluster.ids)
DimPlot(GSM4565823, reduction = "umap", label = TRUE, pt.size = 0.5) + NoLegend()
DimPlot(GSM4565823, reduction = "umap", label = TRUE, pt.size = 0.5) 



